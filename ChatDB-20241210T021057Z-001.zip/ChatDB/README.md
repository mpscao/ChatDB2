# ChatDB
Learning to Query Database Systems Like ChatGPT
